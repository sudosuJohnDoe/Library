1) Put "portal2_dlc3" in "Steam\steamapps\common\Portal 2".
2) Put "test.bsp" in "Steam\steamapps\common\Portal 2\portal2\maps".
3) Launch Portal 2, and wait few minutes.
4) Open console, and type "map test.bsp".